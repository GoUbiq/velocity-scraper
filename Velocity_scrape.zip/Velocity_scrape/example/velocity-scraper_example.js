'use strict';

var velocityScraper = require('../lib/velocity-scraper.js');

velocityScraper.getMeetings();
// => ???